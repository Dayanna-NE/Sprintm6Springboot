package cl.awakelab.sprint06;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprint06Application {

    public static void main(String[] args) {
        SpringApplication.run(Sprint06Application.class, args);
    }

}

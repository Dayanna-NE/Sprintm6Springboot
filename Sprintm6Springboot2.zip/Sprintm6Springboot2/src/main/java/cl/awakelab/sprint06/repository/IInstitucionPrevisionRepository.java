package cl.awakelab.sprint06.repository;

import cl.awakelab.sprint06.entity.InstitucionPrevision;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IInstitucionPrevisionRepository extends JpaRepository<InstitucionPrevision,Integer> {
}

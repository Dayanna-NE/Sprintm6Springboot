
 var table =new DataTable('#lista');

